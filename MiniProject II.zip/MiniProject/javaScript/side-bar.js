function openNav() {
  document.getElementById("sideBar").style.width = "250px";
}

function closeNav() {
  document.getElementById("sideBar").style.width = "0px";
}

// window.addEventListener("scroll", function () {
//   var navbar = document.querySelector(".navbar");
//   var scrollPosition = window.scrollY;

//   if (scrollPosition > 0) {
//     navbar.classList.add("sticky");
//   } else {
//     navbar.classList.remove("sticky");
//   }
// });
